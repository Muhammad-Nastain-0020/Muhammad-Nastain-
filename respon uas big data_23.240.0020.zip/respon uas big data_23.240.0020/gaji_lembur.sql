-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2018 at 04:10 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gaji_lembur`
--

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `no_karyawan` char(5) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `kode_bagian` char(5) NOT NULL,
  `jenis_kel` char(15) NOT NULL,
  PRIMARY KEY (`no_karyawan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`no_karyawan`, `nama`, `alamat`, `tgl_masuk`, `kode_bagian`, `jenis_kel`) VALUES
('K1-01', 'Rani yuliani', 'JL intan no 90 pekalongan', '2007-10-01', 'A-001', 'Perempuan'),
('K1-02', 'Rama yulianto', 'JL Emas no 88 Pekalongan', '2008-02-01', 'A-001', 'Laki-laki'),
('K2-01', 'Sani suryapraja', 'JL sewu no 88 Pekalongan', '2007-02-01', 'A-002', 'Wanita'),
('K3-01', 'fadhli ', 'jl kalimalang no 67 pekalongan', '2008-02-01', 'A-003', 'Pria'),
('K3-02', 'Ahmat yudaha', 'JL intan no 40 pekalongan', '2007-10-01', 'A-003', 'Laki-laki'),
('K4-01', 'Sri Wulandari', 'JL Intan no 80 Pekalongan', '2007-10-01', 'A-004', 'Perempuan'),
('K4-02', 'Tuti Sulastri', 'Jl Arjuna no 50 Pekalongan', '2007-10-01', 'A-004', 'Wanita'),
('K4-03', 'Muhammad kholik', 'JL anggur no 2 pekalongan', '2009-03-01', 'A-004', 'Pria');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
